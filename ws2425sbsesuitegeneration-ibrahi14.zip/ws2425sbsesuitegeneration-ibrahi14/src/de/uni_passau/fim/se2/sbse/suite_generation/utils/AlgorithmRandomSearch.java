package de.uni_passau.fim.se2.sbse.suite_generation.utils;

import de.uni_passau.fim.se2.sbse.suite_generation.algorithms.GeneticAlgorithm;
import de.uni_passau.fim.se2.sbse.suite_generation.chromosomes.Chromosome;
import de.uni_passau.fim.se2.sbse.suite_generation.chromosomes.StatementChromosome;
import de.uni_passau.fim.se2.sbse.suite_generation.chromosomes.StatementChromosomeGenerator;
import de.uni_passau.fim.se2.sbse.suite_generation.stopping_conditions.MaxFitnessEvaluations;
import de.uni_passau.fim.se2.sbse.suite_generation.stopping_conditions.StoppingCondition;

import java.util.ArrayList;
import java.util.List;

public class AlgorithmRandomSearch implements GeneticAlgorithm {

    private static int iterations = 100;
    private Class<?> CUT;
    private StoppingCondition stoppingCondition;

    public AlgorithmRandomSearch(Class<?> CUT, final StoppingCondition stoppingCondition){
        this.CUT = CUT;
        this.stoppingCondition = stoppingCondition;
    }

    @Override
    public List findSolution() {
        List<Chromosome> ls = new ArrayList<>();

        var sc = getStoppingCondition();
        for(int i =0; i < iterations; i++)
//        while(sc.searchCanContinue())
            ls.add(new StatementChromosomeGenerator(CUT).get());

        return ls;
    }

    @Override
    public StoppingCondition getStoppingCondition() {
//        return new MaxFitnessEvaluations(100); // TODO: 500
        return this.stoppingCondition;
    }
}
