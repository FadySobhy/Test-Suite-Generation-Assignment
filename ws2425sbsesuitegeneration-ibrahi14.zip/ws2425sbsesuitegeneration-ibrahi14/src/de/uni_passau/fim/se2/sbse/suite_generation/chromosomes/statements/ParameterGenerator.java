package de.uni_passau.fim.se2.sbse.suite_generation.chromosomes.statements;

import de.uni_passau.fim.se2.sbse.suite_generation.utils.Randomness;

public class ParameterGenerator {

    public static String RandomString(int length){
        StringBuilder s = new StringBuilder();
        for(int i = 0; i < length; i++)
            s.append((char)(Randomness.random().nextInt(32, 126)));
        return s.toString();
    }

    public static Object generateParameterValue(String strType){
        switch (strType) {
            case "int":
                return Randomness.random().nextInt(-1024,1024);
            case "double":
                return Randomness.random().nextDouble(-1024, 1024);
            case "float":
                return Randomness.random().nextFloat(-1024,1024);
            case "boolean":
                return Randomness.random().nextBoolean();
            case "java.lang.String":
                return RandomString(5);
            case "java.lang.Integer":
                return Integer.valueOf(Randomness.random().nextInt(-1024,1024));
            case "java.lang.Double":
                return Double.valueOf(Randomness.random().nextDouble(-1024, 1024));
            case "java.lang.Float":
                return Float.valueOf(Randomness.random().nextFloat(-1024,1024));
            default:
                return null;
        }
    }
}
