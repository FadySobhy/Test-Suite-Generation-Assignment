package de.uni_passau.fim.se2.sbse.suite_generation.fitness_functions;

import de.uni_passau.fim.se2.sbse.suite_generation.chromosomes.Chromosome;
import de.uni_passau.fim.se2.sbse.suite_generation.chromosomes.StatementChromosome;

import java.util.Map;

public class StatementChromosomeFitnessFunction implements FitnessFunction<Chromosome>{
    @Override
    public double applyAsDouble(Chromosome statementChromosome) throws NullPointerException {

        // TODO: follow Pareto Efficiency
        double acc = 0; // TODO: might overflow

        // results from Branch Tracer's getDistance
        Map<Integer, Double> map = statementChromosome.call();
        for(var e : map.entrySet())
            acc += e.getValue().doubleValue();

        return acc;
    }

    @Override
    public boolean isMinimizing() {
        return false;
    }
}
