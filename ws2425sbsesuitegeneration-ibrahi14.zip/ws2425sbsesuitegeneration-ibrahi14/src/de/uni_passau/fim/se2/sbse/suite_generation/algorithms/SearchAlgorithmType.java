package de.uni_passau.fim.se2.sbse.suite_generation.algorithms;

/**
 * Enum specifying the available search algorithms.
 */
public enum SearchAlgorithmType {
    RANDOM_SEARCH,
    MOSA,
}
