package de.uni_passau.fim.se2.sbse.suite_generation.mutation;

import de.uni_passau.fim.se2.sbse.suite_generation.chromosomes.Chromosome;
import de.uni_passau.fim.se2.sbse.suite_generation.chromosomes.StatementChromosome;
import de.uni_passau.fim.se2.sbse.suite_generation.chromosomes.statements.Statement;

import java.util.List;

public class StatementChromosomeMutation implements Mutation{

    @Override
    public Chromosome apply(Chromosome chromosome) {


        var copy_chromosome = chromosome.copy();
        List<Statement> ls = copy_chromosome.getStatements();
        for(Statement s: ls)
            s.mutate();

        return copy_chromosome; // mutated copy
    }

    @Override
    public Object apply(Object o) {
        // TODO: this is a source for problems!!

        Chromosome chromosome = (Chromosome) o;
        var copy_chromosome = chromosome.copy();
        List<Statement> ls = copy_chromosome.getStatements();
        for(Statement s: ls)
            s.mutate();

        return copy_chromosome; // mutated copy
    }
}
