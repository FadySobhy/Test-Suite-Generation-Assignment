package de.uni_passau.fim.se2.sbse.suite_generation.chromosomes.statements;

import java.lang.reflect.Field;
import java.util.Objects;

public class FieldStatement implements Statement {
    private Object obj;
    private Class<?> CUT;

    private int indexField = 0;
    private Field field;

    private String fieldName;
    private String fieldType;
    private Object fieldValue;


    public FieldStatement(Class<?> CUT, Object obj) {
        this.obj = obj;
//        this.CUT = obj.getClass();
        this.CUT = CUT;
        this.indexField = 0;
        init();
    }

    public FieldStatement(Class<?> CUT, Object obj, int indexField) {
        this.obj = obj;
//        this.CUT = obj.getClass();
        this.CUT = CUT;
        this.indexField = indexField;
        init();
    }

    void init() {
        this.field = this.CUT.getDeclaredFields()[this.indexField];
        this.fieldName = this.field.getName();
        this.fieldType = this.field.getType().getName();
        this.fieldValue = ParameterGenerator.generateParameterValue(this.fieldType);

    }


    public Object getFieldValue() {
        return fieldValue;
    }

    public void setFieldValue(Object fieldValue) {
        this.fieldValue = fieldValue;
    }

    public void mutate(){
        var v = ParameterGenerator.generateParameterValue(this.fieldType);
        this.setFieldValue(v);
//        this.run();
    }


    @Override
    public void run() {
        try {
            this.field.setAccessible(true);
            this.field.set(this.obj, this.fieldValue);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }

    }

    @Override
    public String toString() {
        return "FieldStatement{" +
                "obj=" + obj +
                ", CUT=" + CUT +
                ", indexField=" + indexField +
                ", field=" + field +
                ", fieldName=" + fieldName +
                ", fieldType='" + fieldType + '\'' +
                ", fieldValue=" + fieldValue +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FieldStatement that = (FieldStatement) o;
        return indexField == that.indexField && Objects.equals(CUT, that.CUT) && Objects.equals(field, that.field) && Objects.equals(fieldName, that.fieldName) && Objects.equals(fieldType, that.fieldType) && Objects.equals(fieldValue, that.fieldValue);
    }

    @Override
    public int hashCode() {
        return Objects.hash(indexField, field, fieldName, fieldType, fieldValue);
    }
}
