package de.uni_passau.fim.se2.sbse.suite_generation.chromosomes.statements;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Objects;

public class MethodStatement implements Statement {

    private Object obj;
    private Class<?> CUT;
    private int indexMethod;

    private String methodName; // TODO: remove this
    private int methodArgsNum;
    private ArrayList<String> methodsArgsType = new ArrayList<>(); // TODO: remove this
    private ArrayList<Object> methodsArgsVals = new ArrayList<>();

    private Method method;

    public MethodStatement(Class<?> CUT,  Object obj){
        this.obj = obj;
//        this.CUT = obj.getClass();
        this.CUT = CUT;
        this.indexMethod = 0;
        init();
    }
    public MethodStatement(Class<?> CUT, Object obj, int indexMethod){
        this.obj = obj;
//        this.CUT = obj.getClass();
        this.CUT = CUT;
        this.indexMethod = indexMethod;
        init();
    }

    void init() {
        this.method = this.CUT.getDeclaredMethods()[this.indexMethod];
        this.methodArgsNum = method.getParameterCount();
        this.methodName = method.getName();

        for(var p : method.getParameters()){
            var ptype = p.getType().getName();
            methodsArgsType.add(ptype);
            methodsArgsVals.add(ParameterGenerator.generateParameterValue(ptype));
        }
    }

    public void mutate(){
        for(int i =0;i < methodsArgsType.size();i++)
            methodsArgsVals.set(i, ParameterGenerator.generateParameterValue(methodsArgsType.get(i)));
    }


    @Override
    public void run(){
        try {
            this.method.invoke(this.obj, methodsArgsVals.toArray());
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (InvocationTargetException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public String toString() {
        return "MethodStatement{" +
                "CUT=" + CUT +
                ", indexMethod=" + indexMethod +
                ", methodName='" + methodName + '\'' +
                ", methodArgsNum=" + methodArgsNum +
                ", methodsArgsType=" + methodsArgsType +
                ", methodsArgsVals=" + methodsArgsVals +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MethodStatement that = (MethodStatement) o;
        return indexMethod == that.indexMethod && methodArgsNum == that.methodArgsNum && Objects.equals(CUT, that.CUT) && Objects.equals(methodName, that.methodName) && Objects.equals(methodsArgsType, that.methodsArgsType) && Objects.equals(methodsArgsVals, that.methodsArgsVals) && Objects.equals(method, that.method);
    }

    @Override
    public int hashCode() {
        return Objects.hash(indexMethod, methodName, methodArgsNum, methodsArgsType, methodsArgsVals, method);
    }
}
