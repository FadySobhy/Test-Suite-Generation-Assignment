package de.uni_passau.fim.se2.sbse.suite_generation.chromosomes;

public class StatementChromosomeGenerator implements ChromosomeGenerator {
    //TODO: use generics!
    private Class<?> CUT;
    public StatementChromosomeGenerator(Class<?> CUT){
        this.CUT = CUT;
    }
    @Override
    public Chromosome get() {
        return new StatementChromosome(this.CUT);
    }
}
