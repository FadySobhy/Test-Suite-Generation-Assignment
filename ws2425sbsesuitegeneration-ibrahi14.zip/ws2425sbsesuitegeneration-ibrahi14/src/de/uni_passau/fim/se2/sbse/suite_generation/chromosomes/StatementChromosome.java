package de.uni_passau.fim.se2.sbse.suite_generation.chromosomes;

import de.uni_passau.fim.se2.sbse.suite_generation.chromosomes.statements.ConstructorStatement;
import de.uni_passau.fim.se2.sbse.suite_generation.chromosomes.statements.FieldStatement;
import de.uni_passau.fim.se2.sbse.suite_generation.chromosomes.statements.MethodStatement;
import de.uni_passau.fim.se2.sbse.suite_generation.chromosomes.statements.Statement;
import de.uni_passau.fim.se2.sbse.suite_generation.instrumentation.BranchTracer;
import de.uni_passau.fim.se2.sbse.suite_generation.utils.Randomness;
import de.uni_passau.fim.se2.sbse.suite_generation.utils.SelfTyped;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class StatementChromosome extends Chromosome {

    private Class<?> CUT;
    private List<Statement> statements = new ArrayList<>();

    private static final int MAX_STATEMENTS = 50;

    private StatementChromosome() {

    }


    public StatementChromosome(Class<?> CUT) {
        super(); // Uses identity mutation and crossover for testing
        this.CUT = CUT;

        // TODO: pick a random constructor
        var firstStatement = new ConstructorStatement(CUT, 0);

//        statements.add(firstStatement);
        firstStatement.run();

        for(int i = 0; i < MAX_STATEMENTS - 1; i++) {
            var erg = generateRandomStatement(firstStatement.getObject());
            if (erg != null)
                statements.add(erg);
        }

    }

    private StatementChromosome(StatementChromosome other) {
        super(other);
        this.CUT = other.CUT;
        this.statements = new ArrayList<>();

        // Deep copy of statements
        this.statements.addAll(other.statements);
    }


    public Statement generateRandomStatement(Object obj){
        float rand = Randomness.random().nextFloat(0, 1);

        int lenMethods = this.CUT.getDeclaredMethods().length;
        int lenFields = this.CUT.getDeclaredFields().length;

        // 50% chance to generate a Method Statement
        if(rand < 0.5 && lenMethods > 0) {
            // pick a random method
            int randMethodIDX = Randomness.random().nextInt(0, lenMethods);
            return new MethodStatement(this.CUT, obj, randMethodIDX);
        }

        // 50% chance to generate a Field Statement
        if (rand > 0.5 && lenFields > 0) {
            // pick a random field
            int randFieldIDX = Randomness.random().nextInt(0, lenFields);
            return new FieldStatement(this.CUT, obj, randFieldIDX);
        }
        return null;
    }


    @Override
    public Chromosome copy() {
        var c = new StatementChromosome(this);
        // TODO: implement clone!
        return this; // TODO: this is wrong!
    }

//    @Override
//    public boolean equals(Object other) {
//        // TODO: test equality
//        var o = (StatementChromosome)other;
//        if(this.size() != o.size()) return false;
//        for(int i = 0; i < this.size(); i++)
//            if(this.getStatements().get(i) != o.getStatements().get(i))
//                return false;
//        return true;
//    }
//
//    @Override
//    public int hashCode() {
//        // TODO: use intellj's hashcod
//        return 0;
//    }

    @Override
    public Map<Integer, Double> call() throws RuntimeException {
        // NO CONSTRUCTOR STATEMENTS
        for(var s : statements)
            s.run();

        var bt = BranchTracer.getInstance();
        return bt.getDistances();
    }

    @Override
    public List<Statement> getStatements() {
        return statements;
    }

    @Override
    public SelfTyped self() {
        return this;
    }

    @Override
    public String toString() {
        return "StatementChromosome{" +
                "CUT=" + CUT +
                ", statements=" + statements +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        StatementChromosome that = (StatementChromosome) o;
        return Objects.equals(CUT, that.CUT) && Objects.equals(statements, that.statements);
    }

    @Override
    public int hashCode() {
        return Objects.hash(statements);
    }
}
