package de.uni_passau.fim.se2.sbse.suite_generation.chromosomes.statements;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Objects;

public class ConstructorStatement implements Statement{

    /**
     * The reflected class for which we want to generate tests.
     */
    private Class<?> CUT;

    private Object obj;

    private int indexConstructor;
    private Constructor constructor;

    private int argsNum;
    private ArrayList<String> argsType = new ArrayList<>(); // TODO: remove this
    private ArrayList<Object> argsValues = new ArrayList<>();


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ConstructorStatement that = (ConstructorStatement) o;
        return indexConstructor == that.indexConstructor && argsNum == that.argsNum && Objects.equals(CUT, that.CUT) && Objects.equals(argsType, that.argsType) && Objects.equals(argsValues, that.argsValues);
    }

    @Override
    public int hashCode() {
        return Objects.hash(indexConstructor, argsNum, argsType, argsValues);
    }

    public ConstructorStatement(Class<?> CUT) {
        this.CUT = CUT;
        this.indexConstructor = 0;
        init();
    }

    public ConstructorStatement(Class<?> CUT, int indexConstructor) {
        this.CUT = CUT;
        this.indexConstructor = indexConstructor;
        init();
    }


    public void init(){
        // TODO: assert single constructor
//        var c = CUT.getConstructors()[indexConstructor];
         this.constructor = CUT.getDeclaredConstructors()[indexConstructor];
        this.argsNum = this.constructor.getParameterCount();

        for(var p : this.constructor.getParameterTypes()) {
            String ptype = p.getName();
            argsType.add(ptype);
            Object argVal = ParameterGenerator.generateParameterValue(ptype);
            argsValues.add(argVal);
        }

    }

    public void mutate(){
        for(int i =0;i < argsType.size();i++)
            argsValues.set(i, ParameterGenerator.generateParameterValue(argsType.get(i)));
    }

    public Object getObject(){
        return this.obj;
    }

    @Override
    public void run() {
        var c = this.CUT.getConstructors()[this.indexConstructor];
        try {
            this.obj = c.newInstance(argsValues.toArray());
        } catch (InstantiationException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (InvocationTargetException e) {
            throw new RuntimeException(e);
        }

    }

    @Override
    public String toString() {
        return "ConstructorStatement{" +
                "CUT=" + CUT +
                ", indexConstructor=" + indexConstructor +
                ", argsNum=" + argsNum +
                ", argsType=" + argsType +
                ", argsValues=" + argsValues +
                '}';
    }
}
