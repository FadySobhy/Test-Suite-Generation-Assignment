package de.uni_passau.fim.se2.sbse.suite_generation.utils;

import de.uni_passau.fim.se2.sbse.suite_generation.algorithms.GeneticAlgorithm;
import de.uni_passau.fim.se2.sbse.suite_generation.chromosomes.Chromosome;
import de.uni_passau.fim.se2.sbse.suite_generation.chromosomes.StatementChromosome;
import de.uni_passau.fim.se2.sbse.suite_generation.chromosomes.StatementChromosomeGenerator;
import de.uni_passau.fim.se2.sbse.suite_generation.stopping_conditions.MaxFitnessEvaluations;
import de.uni_passau.fim.se2.sbse.suite_generation.stopping_conditions.StoppingCondition;
import de.uni_passau.fim.se2.sbse.suite_generation.fitness_functions.StatementChromosomeFitnessFunction;

import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;

public class AlgorithmRandomSearchUpdated implements GeneticAlgorithm {

    private static final int ITERATIONS = 100;
    private Class<?> CUT;
    private StoppingCondition stoppingCondition;
    private final int populationSize;
    private final StatementChromosomeFitnessFunction fitnessFunction;

    // Archive to store the best solutions
    private final PriorityQueue<Chromosome> archive;

    public AlgorithmRandomSearchUpdated(Class<?> CUT, final StoppingCondition stoppingCondition, int populationSize) {
        this.CUT = CUT;
        this.stoppingCondition = stoppingCondition;
        this.populationSize = populationSize;
        this.fitnessFunction = new StatementChromosomeFitnessFunction();
        this.archive = new PriorityQueue<>((c1, c2) -> Double.compare(fitnessFunction.applyAsDouble(c2), fitnessFunction.applyAsDouble(c1)));
    }

    @Override
    public List<Chromosome> findSolution() {
        List<Chromosome> currentPopulation = new ArrayList<>();

        stoppingCondition.notifySearchStarted();
//        StatementChromosome newChromosome = new StatementChromosomeGenerator(CUT).get();
        var generator = new StatementChromosomeGenerator(CUT);

        // Search process continues while the stopping condition allows
        while (stoppingCondition.searchCanContinue()) {
            // Generate new chromosomes (test cases) randomly
//            for (int i = 0; i < populationSize; i++) {
                Chromosome newChromosome = generator.get();
//                System.out.println(newChromosome);
                currentPopulation.add(newChromosome);

                // Evaluate fitness and add to the archive
                double fitness = fitnessFunction.applyAsDouble(newChromosome);
                if (archive.size() < populationSize) {
                    archive.add(newChromosome);
                } else {
                    // Replace the worst chromosome if the new one is better
                    Chromosome worst = archive.peek();
                    if (fitness > fitnessFunction.applyAsDouble(worst)) {
                        archive.poll();
                        archive.add(newChromosome);
                    }
                }

                // Check if the stopping condition (fitness evaluations) is met
                if (stoppingCondition.searchMustStop()) {
                    break;
                }
//            }
        }

        // Return the archive as the final population of test cases
        return new ArrayList<>(archive);
    }

    @Override
    public StoppingCondition getStoppingCondition() {
        return this.stoppingCondition;
    }
}
