package de.uni_passau.fim.se2.sbse.suite_generation.chromosomes.statements;

import de.uni_passau.fim.se2.sbse.suite_generation.examples.SimpleExample;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FieldStatementTest {

    @Test
    void SampleTest() throws ClassNotFoundException{
        String className ="de.uni_passau.fim.se2.sbse.suite_generation.examples.SimpleExample";
        Class CUT = Class.forName(className);
        var obj = new SimpleExample(500);
        var field = new FieldStatement(CUT, obj, 0);
        System.out.println(field);

        field.setFieldValue(9000);
        field.run();
        System.out.print(field);

    }

}