package de.uni_passau.fim.se2.sbse.suite_generation.utils;

import de.uni_passau.fim.se2.sbse.suite_generation.algorithms.SearchAlgorithmType;
import de.uni_passau.fim.se2.sbse.suite_generation.instrumentation.BranchTracer;
import de.uni_passau.fim.se2.sbse.suite_generation.stopping_conditions.MaxFitnessEvaluations;
import de.uni_passau.fim.se2.sbse.suite_generation.stopping_conditions.StoppingCondition;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AlgorithmBuilderTest {

    @Test
    void buildRandomSearchTest() throws ClassNotFoundException {
        int populationSize = 10;
        String className = "SimpleExample";
        String packageName = "de.uni_passau.fim.se2.sbse.suite_generation.examples";
        StoppingCondition stoppingCondition = new MaxFitnessEvaluations(500);
        AlgorithmBuilder builder = new AlgorithmBuilder(Randomness.random(), stoppingCondition,
                populationSize, className, packageName, BranchTracer.getInstance());
        final var search = builder.build(SearchAlgorithmType.RANDOM_SEARCH);
        System.out.println(search.findSolution());

    }
}