package de.uni_passau.fim.se2.sbse.suite_generation.chromosomes.statements;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ConstructorStatementTest {

    @Test
    void SampleEncode() throws ClassNotFoundException{
        String className ="de.uni_passau.fim.se2.sbse.suite_generation.examples.SimpleExample";
        Class CUT = Class.forName(className);
        var s1 = new ConstructorStatement(CUT, 0);
        System.out.println(s1);
    }

    @Test
    void SampleRun() throws ClassNotFoundException{
        String className ="de.uni_passau.fim.se2.sbse.suite_generation.examples.SimpleExample";
        Class CUT = Class.forName(className);
        var s1 = new ConstructorStatement(CUT);
        s1.run();
        System.out.println(s1.getObject().toString());
    }


}