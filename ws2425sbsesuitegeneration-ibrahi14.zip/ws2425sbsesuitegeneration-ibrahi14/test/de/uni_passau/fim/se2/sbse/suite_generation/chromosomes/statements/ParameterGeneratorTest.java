package de.uni_passau.fim.se2.sbse.suite_generation.chromosomes.statements;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ParameterGeneratorTest {

    @Test
    void generateRandomString(){
        System.out.print(ParameterGenerator.RandomString(4));
    }

    @Test
    void generateParameterValue() {
        System.out.println("test works");
    }

    @Test
    void generateString(){
        String x = "Fady";
        String typeName = x.getClass().getTypeName();

        assertEquals(ParameterGenerator.generateParameterValue(typeName), "HELLO");
    }

    @Test
    void generateInt(){
        int x = 42;
        String typeName = int.class.getName();
        assertEquals(ParameterGenerator.generateParameterValue(typeName), 123);
    }

    @Test
    void generateInteger(){
        Integer x = 42;
        String typeName = x.getClass().getTypeName();
        assertEquals(ParameterGenerator.generateParameterValue(typeName), 456);
    }
    
    @Test
    void generateObject(){
        Object x = new Object();
        String typeName = x.getClass().getTypeName();
        assertNull(ParameterGenerator.generateParameterValue(typeName));

    }
}