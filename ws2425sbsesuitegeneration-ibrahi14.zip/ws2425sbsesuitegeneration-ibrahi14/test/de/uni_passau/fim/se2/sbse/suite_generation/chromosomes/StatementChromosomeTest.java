package de.uni_passau.fim.se2.sbse.suite_generation.chromosomes;

import de.uni_passau.fim.se2.sbse.suite_generation.chromosomes.statements.ConstructorStatement;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class StatementChromosomeTest {
    
    @Test
    void SampleTest() throws ClassNotFoundException{
        String className ="de.uni_passau.fim.se2.sbse.suite_generation.examples.SimpleExample";
        Class CUT = Class.forName(className);
        var c = new StatementChromosome(CUT);
        System.out.println(c);

    }

}