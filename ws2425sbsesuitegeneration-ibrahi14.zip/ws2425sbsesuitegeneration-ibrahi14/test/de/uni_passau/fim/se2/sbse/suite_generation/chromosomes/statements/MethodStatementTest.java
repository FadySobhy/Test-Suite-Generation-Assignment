package de.uni_passau.fim.se2.sbse.suite_generation.chromosomes.statements;

import de.uni_passau.fim.se2.sbse.suite_generation.examples.SimpleExample;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MethodStatementTest {

    @Test
    void SampleTest() throws ClassNotFoundException{
        String className ="de.uni_passau.fim.se2.sbse.suite_generation.examples.SimpleExample";
        Class CUT = Class.forName(className);
        var obj = new SimpleExample(500);
        var m1 = new MethodStatement(CUT, obj, 1);
        System.out.println(m1);
        m1.run();
    }

}